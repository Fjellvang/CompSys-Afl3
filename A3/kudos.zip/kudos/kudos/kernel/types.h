#ifndef KUDOS_KERNEL_TYPES_H
#define KUDOS_KERNEL_TYPES_H

typedef int TID_t;

#endif // KUDOS_KERNEL_TYPES_H
