/*
 * Exception Handling
 */

#ifndef KUDOS_KERNEL_X86_64_EXCEPTION_H
#define KUDOS_KERNEL_X86_64_EXCEPTION_H

//Setup Exceptions
void exception_init();

#endif // KUDOS_KERNEL_X86_64_EXCEPTION_H
