/*
 * Register name definitions for assembler code.
 */

#ifndef KUDOS_LIB_REGISTERS_H
#define KUDOS_LIB_REGISTERS_H

#include "mips32/registers.h"

#endif // KUDOS_LIB_REGISTERS_H
