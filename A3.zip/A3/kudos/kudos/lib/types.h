/*
 * Architecture-specific integer typedefs
 */

#ifndef KUDOS_LIB_TYPES_H
#define KUDOS_LIB_TYPES_H

#include <types.h> // Includes mips/types.h or x86_types.h as appropriate.

#endif // KUDOS_LIB_TYPES_H
