This is the source code for |docs|.

.. |docs| image:: https://readthedocs.org/projects/kudos/badge/?version=latest
    :alt: Documentation Status
    :scale: 100%
    :target: https://kudos.readthedocs.org/en/latest/?badge=latest

Building Locally
================

You need 3 Python packages:

    pip3 install --user sphinx sphinx-autobuild sphinx_rtd_theme

Then you can just use ``make``:

    make html
